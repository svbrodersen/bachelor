#include <stdint.h>
#define UART_ADDR 0x10000000

void uart_init(void);
void outbyte(unsigned char);
