#define TIME_QUANTANT 10000000
void set_interrupt_timer();
void init_interrupts();
