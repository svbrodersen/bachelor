#include <stddef.h>
void init_palloc();
unsigned char *palloc(size_t size);
void get_hartid(int *);
